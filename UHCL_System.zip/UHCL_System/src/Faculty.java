import java.util.ArrayList;

public class Faculty extends User {
	

	public Faculty() {
		super();
	}
	
	public Faculty(String name, String major, String loginId, String password) {
		super();
		this.name = name;
		this.major = major;
		this.loginId = loginId;
		this.password = password;
		this.userType = "faculty" ;
	}

}
