
public class Course {
	private String courseId;
	private String major;
	private String facutly;
	private int capacity = 1;
	private int enrollNumber;
	private String status = "open";
	private StringBuffer notes = new StringBuffer();
	
	public Course(String courseId, String facutly, String major) {
		super();
		this.courseId = courseId;
		this.major = major;
		this.facutly = facutly;
	}

	public String getCourseId() {
		return courseId;
	}

	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public String getFacutly() {
		return facutly;
	}

	public void setFacutly(String facutly) {
		this.facutly = facutly;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public int getEnrollNumber() {
		return enrollNumber;
	}

	public void setEnrollNumber(int enrollNumber) {
		this.enrollNumber = enrollNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}


	public StringBuffer getNotes() {
		return notes;
	}

	public void setNotes(StringBuffer notes) {
		this.notes = notes;
	}
	
	@Override
	public boolean equals(Object obj) {
		Course course = (Course) obj;
		
		if(this.courseId.equals(course.getCourseId())){
			return true;
		}
		return false;
	}

}
