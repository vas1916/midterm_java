import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class UHCL_System {

	public static ArrayList<Course> allCourses = new ArrayList<Course>();
	public static ArrayList<User> allUsers = new ArrayList<User>();
	public static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		Course isam5638 = new Course("ISAM 5638", "Dr. Lin", "MIS");
		Course isam5735 = new Course("ISAM 5735", "Dr. Lin", "MIS");
		Course isam5331 = new Course("ISAM 5331", "Dr. Saleem", "MIS");
		Course acct6200 = new Course("ACCT 6200", "Dr. Lehman", "Accounting");

		allCourses.add(isam5638);
		allCourses.add(isam5735);
		allCourses.add(isam5331);
		allCourses.add(acct6200);

		Faculty lin = new Faculty("Dr. Lin", "MIS", "lin", "1234");
		Faculty saleem = new Faculty("Dr. Saleem", "MIS", "saleem", "1234");
		Faculty lehman = new Faculty("Dr. Lehman", "Accounting", "lehman", "1234");

		allUsers.add(lin);
		allUsers.add(saleem);
		allUsers.add(lehman);

		allUsers.add(new Student("Jean", "MIS", "jean", "4321"));
		allUsers.add(new Student("Jack", "Accounting", "jack", "4321"));
		allUsers.add(new Student("Mike", "MIS", "mike", "4321"));
		allUsers.add(new Student("Joan", "MIS", "joan", "4321"));

		lin.getCourses().add(isam5638);
		lin.getCourses().add(isam5735);
		saleem.getCourses().add(isam5331);
		lehman.getCourses().add(acct6200);

		User user = null;
		while (true) {
			System.out.println("\n\nGo Hawks!");
			System.out.println("1: e-Service");
			System.out.println("2: Blackboard");
			System.out.println("x: Leave");

			String input = scanner.next();
			if ("1".equals(input)) {
				user = login();
				if (user != null) {
					eService(user);
				} else {
					System.out.println("please enter correct details");
				}
			} else if ("2".equals(input)) {
				user = login();
				if (user != null) {
					blackboard(user);
				} else {
					System.out.println("please enter correct details");
				}
			} else if ("x".equals(input)) {
				break;
			}
		}
		System.out.println("You have successfully logged out!");
		scanner.close();
	}

	private static void eService(User user) {
		if ("faculty".equals(user.getUserType())) {
			while (true) {
				System.out.println("\nWelcome to UHCL eService:");
				System.out.println("v: View my courses");
				System.out.println("x: Logout");

				String input = scanner.next();
				if ("v".equals(input)) {
					for (Course course : user.getCourses()) {
						System.out.println(course.getCourseId());
						System.out.println("Students Enrolled : " + course.getEnrollNumber());
					}
				} else if ("x".equals(input)) {
					break;
				}
			}

		} else if ("student".equals(user.getUserType())) {
			while (true) {
				System.out.println("\nWelcome to UHCL eService:");
				System.out.println("v: View my courses");
				System.out.println("r: register a course");
				System.out.println("x: Logout");

				String input = scanner.next();
				if ("v".equals(input)) {
					if (user.getCourses().size() > 0) {
						for (Course course : user.getCourses()) {
							System.out.println(course.getCourseId() + ", Instructor: " + course.getFacutly());
						}
					} else {
						System.out.println("You do not have any course registered!");
					}
				} else if ("r".equals(input)) {
					System.out.println("Welcome to register a new course!\nThese are the courses available to you:");
					int i = 1;
					ArrayList<Course> indexCourses = new ArrayList<Course>();
					for (Course course : allCourses) {
						if (course.getMajor().equals(user.getMajor())) {
							if (!user.getCourses().contains(course) && course.getStatus().equals("open")) {
								indexCourses.add(course);
								System.out.println(i++ + " : " + course.getCourseId());
							}
						}
					}
					System.out.println("Or any other key to exit");
					input = scanner.next();
					if (!input.isEmpty()) {

						try {
							int courseIndex = Integer.valueOf(input);
							if (courseIndex > 0 && courseIndex < i) {
								Course course = indexCourses.get(courseIndex - 1);
								course.setStatus("full");
								course.setEnrollNumber(course.getEnrollNumber()+1);
								user.getCourses().add(course);
								System.out.println("The course is added to your schedule!");
							}
						} catch (NumberFormatException e) {
						}
					}

				} else if ("x".equals(input)) {
					break;
				}
			}

		}
	}

	private static void blackboard(User user) {
		while (true) {
			System.out.println("\nWelcome to UHCL Blackboard!");
			int i = 1;
			for (Course course : user.getCourses()) {
				System.out.println(i++ + ": " + course.getCourseId());
			}
			System.out.println("x: leave Blackboard");

			String input = scanner.next();
			if (!"x".equals(input)) {
				Course course = user.getCourses().get(Integer.valueOf(input) - 1);
				if ("faculty".equals(user.getUserType())) {
					while (true) {
						System.out.println("\nv: View course notes");
						System.out.println("p: Post course notes");
						System.out.println("x: leave the course");
						input = scanner.next();
						if ("v".equals(input)) {
							System.out.println("Course notes of " + course.getCourseId());
							if (course.getNotes().toString().isEmpty()) {
								System.out.println("None");
							} else {
								System.out.println(course.getNotes());
							}
						} else if ("p".equals(input)) {
							System.out.println("Please enter your new note:");
							input = scanner.next();
							input += scanner.nextLine();
							LocalDateTime current = LocalDateTime.now();
							DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
							String formatted = current.format(formatter);
							course.getNotes().append(formatted + " : " + input + "\n");
							System.out.println("Your note is added to the course. Your students can see it now");

						} else if ("x".equals(input)) {
							break;
						}
					}
				} else if ("student".equals(user.getUserType())) {
					while (true) {
						System.out.println("\nv: View course notes");
						System.out.println("x: leave the course");
						input = scanner.next();
						if ("v".equals(input)) {
							System.out.println("Course notes of " + course.getCourseId());
							if (course.getNotes().toString().isEmpty()) {
								System.out.println("None");
							} else {
								System.out.println(course.getNotes());
							}
						} else if ("x".equals(input)) {
							break;
						}
					}

				}

			} else {
				break;
			}
		}
	}

	private static User login() {
		System.out.println("Please enter your login id: ");
		String loginId = scanner.next();
		System.out.println("Please enter your password: ");
		String password = scanner.next();

		for (Iterator<User> iterator = allUsers.iterator(); iterator.hasNext();) {
			User user = iterator.next();
			if (user.getLoginId().equals(loginId)) {
				if (user.getPassword().equals(password)) {
					return user;
				}
				break;
			}
		}
		return null;
	}

}
