
public class Student extends User {
	public Student(String name, String major, String loginId, String password) {
		super();
		this.name = name;
		this.major = major;
		this.loginId = loginId;
		this.password = password;
		this.userType = "student";
	}

}
